#!/bin/bash
rm ipi.*
rm RESTART
rm \#*
